from django.shortcuts import render, get_object_or_404
from .models import produtos
from .models import fornecedores


# Create your views here.
def home(request):
    return render(request, 'home.html')

def cadastrar(request):

    return render(request, 'estoque/cadastrar.html')

def cadastrarf(request):

    return render(request, 'fornecedor/cadastrarf.html')



def estoque(request):
    listar = {
        'listar': produtos.objects.all()
    }
    return render(request, 'estoque/estoque.html', listar)


def fornecedor(request):
    listarF = {
        'listarF': fornecedores.objects.all()
    }
    return render(request, 'fornecedor/fornecedor.html', listarF)

def gravar(request):
    novo = produtos()
    novo.marca = request.POST.get('marca')
    novo.modelo = request.POST.get('modelo')
    novo.qtde = request.POST.get('qtde')
    novo.valor = request.POST.get('valor')
    novo.save()
    return render(request, 'estoque/cadastrar.html')


def gravarF(request):
    novof = fornecedores()
    novof.nome = request.POST.get('nome')
    novof.cnpj = request.POST.get('cnpj')
    novof.end = request.POST.get('end')
    novof.contato = request.POST.get('contato')
    novof.telefone = request.POST.get('telefone')
    novof.email = request.POST.get('email')
    novof.save()
    listarF = {
        'listarF': fornecedores.objects.all()
    }
    return render(request, 'fornecedor/fornecedor.html', listarF)


def apagar(request, id):
    produto = get_object_or_404(produtos, id=id)
    produto.delete()
    listar = {
        'listar': produtos.objects.all() 
    }
    return render(request, 'estoque/estoque.html',listar)


def apagarF(request, id):
    fornecedor = get_object_or_404(fornecedores, id=id)
    fornecedor.delete()
    listarF = {
        'listarF': fornecedores.objects.all() 
    }
    return render(request, 'fornecedor/fornecedor.html', listarF)

    