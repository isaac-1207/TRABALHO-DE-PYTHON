from django.db import models

# Create your models here.

class produtos(models.Model):
    marca = models.CharField(max_length=100)
    modelo = models.CharField(max_length=100)
    qtde = models.IntegerField(default=0)
    valor = models.FloatField(default=0)

class fornecedores(models.Model):
    nome = models.CharField(max_length=100)
    cnpj = models.CharField(max_length=100)
    end = models.CharField(max_length=200)
    contato = models.CharField(max_length=100)
    telefone = models.CharField(max_length=50)
    email = models.CharField(max_length=100)